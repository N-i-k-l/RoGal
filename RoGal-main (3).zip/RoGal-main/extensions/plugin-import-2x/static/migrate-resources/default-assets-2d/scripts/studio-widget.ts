import { Widget, _decorator } from "cc";
const { ccclass } = _decorator;

@ccclass('StudioWidget')
export class StudioWidget extends Widget {
    _validateTargetInDEV() {}
}
